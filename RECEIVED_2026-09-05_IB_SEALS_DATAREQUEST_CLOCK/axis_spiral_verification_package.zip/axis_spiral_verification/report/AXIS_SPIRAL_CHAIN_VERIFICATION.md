# Axis-Spiral Chain — Exact Subgroup Verification

## Verified chain

```text
{e} ⊂ Z₂ ⊂ A₄ ⊂ S₄ ⊂ PSL(2,7) ⊂ G₂(2)
```

The degree-63 permutation model used in the executed SageMath/GAP computation was

```gap
G := PrimitiveGroup(63,2);
```

with

```text
|G| = 12096
```

The unique order-168 subgroup class used throughout gave

```text
|H| = 168
IdGroup(H) = [168,42]
Structure(H) = PSL(3,2)
```

`PSL(3,2) ≅ PSL(2,7)`, so this is the required intermediate group.

## 1. G₂(2) → PSL(2,7)

**PASS**

```text
Order-168 subgroup classes = 1
|H| = 168
IdGroup(H) = [168,42]
Structure(H) = PSL(3,2)
```

A single fixed representative `H` was retained for all subsequent tests.

## 2. PSL(2,7) → S₄

**PASS**

Inside the fixed `H`:

```text
S4 classes inside H = 2
```

For each of the two classes:

```text
|S4| = 24
IdGroup(S4) = [24,12]
class length in H = 7
|N_H(S4)| = 24
IdGroup(N_H(S4)) = [24,12]
structure N_H(S4) = S4
|N_G(S4)| = 48
IdGroup(N_G(S4)) = [48,48]
structure N_G(S4) = C2 x S4
class length in G = 252
```

Thus the exact inclusion is established in one model:

```text
S₄ < H < G
```

There are 2 S₄ conjugacy classes in `H`, each of length 7.

## 3. S₄ → A₄

**PASS**

For each of the two fixed S₄ representatives:

```text
A4 classes inside this S4 = 1
|A4| = 12
IdGroup(A4) = [12,3]
class length in S4 = 1
|N_S4(A4)| = 24
IdGroup(N_S4(A4)) = [24,12]
structure N_S4(A4) = S4
|N_H(A4)| = 24
IdGroup(N_H(A4)) = [24,12]
structure N_H(A4) = S4
class length in H = 7
|N_G(A4)| = 48
IdGroup(N_G(A4)) = [48,48]
structure N_G(A4) = C2 x S4
class length in G = 252
```

The same fixed `H` was used, and A₄ was found independently inside each S₄.

## 4. A₄ → Z₂

**PASS**

For the fixed A₄:

```text
Z2 classes inside A4 = 1
|Z2| = 2
IdGroup(Z2) = [2,1]
class length in A4 = 3
|N_A4(Z2)| = 4
structure N_A4(Z2) = C2 x C2
|N_S4(Z2)| = 8
structure N_S4(Z2) = D8
|N_H(Z2)| = 8
structure N_H(Z2) = D8
|N_G(Z2)| = 192
structure N_G(Z2) = (SL(2,3) : C4) : C2
class length in H = 21
class length in G = 63
```

Thus Z₂ is verified inside the same fixed A₄, S₄, and H.

## 5. Z₂ → {e}

**PASS**

```text
|{e}| = 1
N_G({e}) = G
class length = 1
```

The trivial subgroup is unique and is normalized by all of `G`.

# Consolidated table

| Level | Order | Identification | Class data | Normalizer data |
|---|---:|---|---|---|
| G₂(2) | 12096 | degree-63 primitive model | — | — |
| PSL(2,7) | 168 | [168,42], PSL(3,2) | 1 class in G | — |
| S₄ | 24 | [24,12] | 2 classes in H, length 7 each | N_H=S₄; N_G=C₂×S₄, order 48 |
| A₄ | 12 | [12,3] | 1 class in each S₄ | N_S₄=N_H=S₄; N_G=C₂×S₄ |
| Z₂ | 2 | [2,1] | 1 class in A₄, length 3 | N_A₄=V₄; N_S₄=N_H=D₈; N_G order 192 |
| {e} | 1 | trivial | unique, length 1 | N_G=G |

# Reproducibility note

The files under `logs/` preserve the numerical outputs supplied from the executed SageMathCell/GAP runs.

The file under `code/` is a clean reconstruction of the subgroup-search workflow. The conversation did not preserve every character of every historical intermediate command, so it is explicitly a reconstruction rather than a byte-for-byte transcript.

Known execution environment:

```text
SageMathCell
Python 3.12
Sage interface to GAP
```

The exact SageMathCell build/package revision was not recorded in the supplied output.
