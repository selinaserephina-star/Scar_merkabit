# SageMathCell Python cell
# Reconstruct the subgroup-chain verification without hardcoding expected counts.
from sage.all import gap

gap.eval(r'''
G := PrimitiveGroup(63,2);;
Print("|G| = ", Size(G), "\n");;
Print("degree = ", NrMovedPoints(G), "\n");;

# Unique order-168 subgroup class
ccG := ConjugacyClassesSubgroups(G);;
Hclasses := Filtered(ccG, c -> Size(Representative(c)) = 168);;
Print("Order-168 subgroup classes = ", Length(Hclasses), "\n");;
H := Representative(Hclasses[1]);;
Print("|H| = ", Size(H), "\n");;
Print("IdGroup(H) = ", IdGroup(H), "\n");;
Print("Structure(H) = ", StructureDescription(H), "\n");;

# S4 classes in fixed H
ccH := ConjugacyClassesSubgroups(H);;
S4classes := Filtered(ccH, c -> Size(Representative(c)) = 24
    and IdGroup(Representative(c)) = [24,12]);;
Print("S4 classes inside H = ", Length(S4classes), "\n");;

for i in [1..Length(S4classes)] do
  S := Representative(S4classes[i]);;
  Print("\nS4 class ", i, "\n");;
  Print("|S4| = ", Size(S), "\n");;
  Print("IdGroup(S4) = ", IdGroup(S), "\n");;
  Print("class length in H = ", Size(H)/Size(Normalizer(H,S)), "\n");;
  Print("|N_H(S4)| = ", Size(Normalizer(H,S)), "\n");;
  Print("N_H structure = ", StructureDescription(Normalizer(H,S)), "\n");;
  Print("|N_G(S4)| = ", Size(Normalizer(G,S)), "\n");;
  Print("N_G structure = ", StructureDescription(Normalizer(G,S)), "\n");;

  # A4 classes in this fixed S4
  ccS := ConjugacyClassesSubgroups(S);;
  A4classes := Filtered(ccS, c -> Size(Representative(c)) = 12
      and IdGroup(Representative(c)) = [12,3]);;
  Print("A4 classes inside this S4 = ", Length(A4classes), "\n");;

  for j in [1..Length(A4classes)] do
    A := Representative(A4classes[j]);;
    Print("A4 class ", j, "\n");;
    Print("|A4| = ", Size(A), "\n");;
    Print("IdGroup(A4) = ", IdGroup(A), "\n");;
    Print("|N_S4(A4)| = ", Size(Normalizer(S,A)), "\n");;
    Print("N_S4 structure = ", StructureDescription(Normalizer(S,A)), "\n");;
    Print("|N_H(A4)| = ", Size(Normalizer(H,A)), "\n");;
    Print("N_H structure = ", StructureDescription(Normalizer(H,A)), "\n");;
    Print("|N_G(A4)| = ", Size(Normalizer(G,A)), "\n");;

    # Z2 classes in this fixed A4
    ccA := ConjugacyClassesSubgroups(A);;
    Z2classes := Filtered(ccA, c -> Size(Representative(c)) = 2
        and IdGroup(Representative(c)) = [2,1]);;
    Print("Z2 classes inside A4 = ", Length(Z2classes), "\n");;

    for k in [1..Length(Z2classes)] do
      Z2 := Representative(Z2classes[k]);;
      Print("Z2 class ", k, "\n");;
      Print("|Z2| = ", Size(Z2), "\n");;
      Print("IdGroup(Z2) = ", IdGroup(Z2), "\n");;
      Print("class length in A4 = ", Size(A)/Size(Normalizer(A,Z2)), "\n");;
      Print("|N_A4(Z2)| = ", Size(Normalizer(A,Z2)), "\n");;
      Print("N_A4 structure = ", StructureDescription(Normalizer(A,Z2)), "\n");;
      Print("|N_S4(Z2)| = ", Size(Normalizer(S,Z2)), "\n");;
      Print("N_S4 structure = ", StructureDescription(Normalizer(S,Z2)), "\n");;
      Print("|N_H(Z2)| = ", Size(Normalizer(H,Z2)), "\n");;
      Print("N_H structure = ", StructureDescription(Normalizer(H,Z2)), "\n");;
      Print("|N_G(Z2)| = ", Size(Normalizer(G,Z2)), "\n");;
      Print("N_G structure = ", StructureDescription(Normalizer(G,Z2)), "\n");;
      Print("class length in H = ", Size(H)/Size(Normalizer(H,Z2)), "\n");;
      Print("class length in G = ", Size(G)/Size(Normalizer(G,Z2)), "\n");;
    od;
  od;
od;

# Trivial subgroup
E := TrivialSubgroup(G);;
Print("\n|{e}| = ", Size(E), "\n");;
Print("N_G({e}) = G, order = ", Size(Normalizer(G,E)), "\n");;
Print("class length = ", Size(G)/Size(Normalizer(G,E)), "\n");;
''');
