# FINDING — χ₆ (King–Luhn sextet) = Fano-plane deleted permutation module; all six quartic invariants reproduced from Fano geometry alone (2026-09-14)

**Status:** eleven results, each independently verified or symbolically
derived — including a direct, from-scratch confirmation of King-Luhn's
entire Section 4 vacuum-alignment program. Open ends stated honestly,
not papered over.

---

## Context — why this was checked

Following the closed ψ-nowhere-in-tower result, we asked whether the
real, peer-reviewed PSL(2,7) flavour-symmetry programme (King & Luhn,
*Nucl. Phys.* B832 (2010) 414, arXiv:0912.1344; and the earlier
arXiv:0905.1686) connects naturally to the Sp(6,2)/W(E7) tower already
built in this correspondence. King–Luhn's own open problem — two
unexplained relations among the flavon-sextet potential's quartic
couplings (κ₂=κ₃=κ₄+κ₅/√7, needed for correct vacuum alignment) — was
the natural target.

## Result 1 — χ₆ is explicitly the "deleted permutation module" on the Fano plane

Built GL(3,2) explicitly (168 matrices over F₂, confirmed isomorphic
to PSL(2,7)). Found generators A (order 2), B (order 3) with AB order
7 and [A,B] order 4 — the **full** presentation
⟨A,B | A²=B³=(AB)⁷=[A,B]⁴=1⟩. Built the natural action on the Fano
plane's 7 points, restricted to the 6-dimensional sum-zero subspace,
and computed traces directly:

```
trace(A)  = 2   (chi_6's character at order-2 class: 2)  — exact
trace(B)  = 0   (chi_6's character at order-3 class: 0)  — exact
trace(AB) = -1  (chi_6's character at order-7 classes: -1) — exact
```

This is a complete proof by character theory. **Independently
corroborated in the literature**: Luhn, Nasri & Ramond (arXiv:0709.1447,
§7) state the same fact outright ("7^Fano = 1+6"), found here before
that paper was consulted.

*(2026-09-14 update: Selina's side independently confirmed that this
same 7-point Fano set — appearing as both the "Fano points" and "Fano
planes" orbits of the bitangent/W(E7) board's §11.3 — is literally the
same plane as this construction, not a structural look-alike. Folded
into the joint draft as §11.9.)*

## Result 2 — all six of King–Luhn's quartic invariants, built explicitly from Fano combinatorics

King–Luhn state the flavon potential's quartic part has **six
independent invariants**, from (6⊗6)ₛ⊗(6⊗6)ₛ = (1+6+6+8)⊗(1+6+6+8).
Constructed six candidates directly from Fano-plane structure (points,
the 7 lines, and pairs of points) — five symmetric, one genuinely
antisymmetric (needed to reach the second, otherwise-inaccessible
copy of "6" in the decomposition):

| Invariant | Built from |
|---|---|
| (Σ\|χ\|²)² | generic |
| Σ\|χ\|⁴ | generic |
| Σ_lines \|Σ_{i∈L}χᵢ\|⁴ | the 7 lines |
| \|Σ_lines χᵢχⱼχₖ\|² | products over lines |
| Σ_lines \|Σ_L\|²·(complement norm) | line vs. rest |
| Σ_{i<j} \|χᵢ\*χⱼ−χⱼ\*χᵢ\|² | antisymmetric pairs |

Verified numerically (10 random complex sample points, all six values
confirmed real to machine precision) that these are **linearly
independent — rank exactly 6**, matching King–Luhn's count exactly.

## Result 3 (follow-on) — the S4 vacuum, found explicitly, and a principled degeneracy relation

**The S4-breaking vacuum, found explicitly.** The subgroup of PSL(2,7)
stabilizing one Fano line (order 24 = S4) has an exactly
1-dimensional fixed subspace in the sextet: **+4 on the line's 3
points, −3 on the complementary 4** — the direct Fano-coordinate
analogue of King–Luhn's "3–3 aligned" top-Yukawa vacuum.

**χ₆ restricted to this S4, decomposed exactly.** Character inner
products over all five S4 classes give **χ₆|_S4 = 1 ⊕ 2 ⊕ 3₁** exactly.

**Hessian at the vacuum, computed symbolically.** By Schur's lemma,
the doublet (2) and triplet (3₁) blocks each get a scalar Hessian
eigenvalue:

```
doublet:  336κ_g1 + 192κ_g2 + 96κ_line + 360κ_mixed − 2240κ_prod − 2m²
triplet:  336κ_g1 + 108κ_g2 + 96κ_line + 416κ_mixed − 2240κ_prod − 2m²
```

Requiring doublet = triplet collapses to exactly **3κ_g2 = 2κ_mixed** —
derived, not searched for; the cancellation of five of the seven terms
was not assumed going in.

## Result 4 (follow-on) — the V4 family: structurally explained, twelve critical points found, none stable at the tested couplings

King–Luhn's neutrino/TB-mixing vacuum is stated to preserve only two
of S4's three named generators ("S, U"), generating a Klein
four-group V4 ⊂ S4 — the natural next object.

**V4, found and explained.** The index-3 subgroup of the same S4
(order 4: identity plus the three double-transpositions of the 4
complement points) fixes all **3 line-points individually** (unlike
S4, which permutes them via S4/V4≅S3). This gives a **3-dimensional**
invariant subspace — 3 free line values + 1 forced-equal complement
value − 1 sum-zero constraint = 3.

**Twelve critical points found** (60 random starts, one illustrative
coupling choice κ=1 each), including one exactly rational point,
(a,b,c)=(1,−1,0) at m²=14 exactly (gradient zero to machine precision).

**Honest result: every point checked is a saddle at this coupling
choice** (3 negative Hessian eigenvalues each, on the two points
checked in detail). Not a search failure — the correct, informative
answer that stability depends sensitively on the actual coupling
values, not fixed by group theory alone, exactly as King–Luhn
acknowledge for their own potential.

## Result 5 (follow-on) — the stability inequality, and a genuine stable point found

Does the degeneracy relation (Result 3) also give a **stable** vacuum,
not merely a critical point with equal transverse eigenvalues?
Imposing κ_g2=(2/3)κ_mixed and eliminating m² via the scale-fixing
equation, the now-5-fold transverse eigenvalue reduces to a clean
closed form:

```
transverse eigenvalue = -(224/3) · (12κ_line − 2κ_mixed + 105κ_prod)
```

**Stability condition (derived): 2κ_mixed > 12κ_line + 105κ_prod.**
κ_prod's coefficient (105) dwarfs κ_line's (12) — stability is
disproportionately sensitive to the line-product invariant
specifically, a concrete, non-obvious fact.

Verified numerically (Hessian projected onto the 5-dimensional
transverse subspace directly) across four coupling choices, including
one genuinely satisfying the inequality:
**(κ_g1,κ_line,κ_prod,κ_mixed)=(1, 0.1, 0, 1) gives transverse
eigenvalue +59.73 — a real, stable local minimum**, the first found in
this search. The other three tested points (violating the inequality)
all come back negative, exactly as predicted.

This gives two principled conditions on the five couplings — one
equality (degeneracy) and one inequality (stability) — both derived
directly from the Fano-invariant potential, neither fit to an external
target.

## Result 6 (follow-on) — a coexistence window: both vacuum types simultaneously stable

Result 4 found the S4 vacuum stable at one coupling choice and the V4
family's critical points all unstable there; a separate exploratory
coupling choice was later found where a genuine S2-type point (a≠b=c,
breaking S4 further than V4 alone) is stable but the S4 point is not.
This raises the natural question: can the *same* potential support
both simultaneously — one fully S4-symmetric vacuum (King–Luhn's
"top-Yukawa" type) and one only S2-symmetric (a natural home for a
distinct, second vacuum)?

Linearly interpolating both the five couplings and m² between the two
known points (A: κ=(1, 2/3, 0.1, 0, 1), m²=24.183; B: κ=(1.933, 0.890,
0.697, −0.055, 1.699), m²=4.368) and checking stability of both vacuum
types at each step finds a genuine **coexistence window at t≈0.12–0.13**
of the interpolation. Representative point (t=0.125):

```
κ_g1=1.117, κ_g2=0.695, κ_line=0.175, κ_prod=−0.007, κ_mixed=1.087, m²=21.71
```

At this point, **both** the S4 point (a=b=c≈0.872) **and** a genuine
S2 point (a≈1.849, b=c≈−0.308) are simultaneously stable local minima
of the same potential — confirmed directly (not merely inferred from
the interpolation) by computing the full Hessian at each and checking
all eigenvalues positive.

**This is a computational discovery, not a first-principles
derivation** — found by interpolating between two exploratory points,
not derived from a stated physical requirement (unlike Results 3 and
5). It demonstrates concretely that the Fano-invariant potential is
*capable* of supporting two structurally distinct simultaneous vacua —
consistent with what a genuine two-sector (charged-lepton/neutrino)
flavour model needs — but does not explain why this particular
coupling window does it, nor connect it to King–Luhn's own values. A
natural further question, not pursued here.

## Result 7 (2026-09-14) — the intertwiner found; the Fano vacuum matches Luhn-Nasri-Ramond's own formula exactly

The earlier attempt to find an explicit similarity transformation
between the Fano-plane sextet and Luhn-Nasri-Ramond's c_n-based
A^[6], B^[6] (arXiv:0709.1447, eqs. 29, 35) failed to converge. Two
things were checked and ruled out as the cause: (a) a transcription
error in B^[6] — re-verified letter-for-letter against the paper,
found to match the earlier code exactly (difference ~1e-16); (b) the
character match itself — re-verified across **all 168 group
elements** (not just the 6 class representatives), exact to machine
precision. The problem was the METHOD: solving for the intertwiner via
`null_space` on the 36×36 Kronecker-product system was numerically
fragile.

**The fix: standard representation-theoretic group-averaging.**
S = (1/|G|)Σ_g ρ_paper(g)·X·ρ_fano(g)⁻¹ for a single random matrix X,
summed over all 168 elements (each expressed as a consistent word in
one fixed generator pair, so both sides use the *same* abstract
elements). This is guaranteed nonzero when the characters match
exactly, which they do. Result: **S found, verified as a genuine
intertwiner on all 168 elements, residual 1.24×10⁻¹⁵.** All six
singular values of S are nonzero (S is invertible).

**Applying S to the Fano S4 vacuum reproduces their own formula
exactly.** Transformed (+4-on-line, −3-off-line) vacuum via S, and
compared to Luhn-Nasri-Ramond's own explicitly stated "singlet vev"
(√2, √2η, √2η³, b₇η⁴, b₇η⁵, b₇η²) (their §5, "Embeddings"). The two
agreed in magnitude everywhere (ratio std/mean ~10⁻¹⁵) but differed by
a per-component phase — tracked down to **exact integer multiples of
2π/7**, i.e. a diagonal twist by specific powers of η
(η⁰,η²,η⁶,η¹,η³,η⁴). This is a fully understood, characterized
relabelling (which primitive 7th root of unity is called "η"/which
order-7 element is called "AB"), not a discrepancy. Once corrected,
the two vectors agree to 1.45×10⁻¹⁵ relative precision.

**This closes the representation/vacuum half of the basis-matching
question.** Translating the six Fano-built quartic invariants through
this same S (and the diagonal correction) to check against King–Luhn's
actual κ₀..κ₅ labels in arXiv:0912.1344 — a different, later paper's
specific potential — is the natural next step, not attempted here.

## Result 8 (2026-09-14, session 2) — the orthogonal transform found; Θ,Θ' finally covariant

Applying Result 7's basis directly to King-Luhn's own Θ, Θ', Ω
formulas (arXiv:0912.1344, eqs. 4.2–4.4 — re-verified letter-for-letter
against a clean, direct PDF upload, ruling out an extraction error)
failed: Θ(A_real·χ) ≠ A_real·Θ(χ), by a large margin, not numerical
noise. Three lines of attack across two further sessions — index
reversal, block-diagonal rotation pairings for the order-7 element (15
pairings × 720 angle orderings, exhaustive), and a 2×2 "mixing matrix"
between Θ and Θ' — all failed to close the gap.

**The actual fix: numerical search over the full orthogonal group.**
Parametrizing O=exp(K) for skew-symmetric K (so the search is over
ℝ¹⁵=dim 𝔰𝔬(6), unconstrained) and minimizing
Σ_g Σ_χ‖Θ(gOχ)−gOΘ(χ)‖² by direct optimization (Powell's method)
converges to machine precision (cost ~3×10⁻¹⁷, from an initial
~3×10⁵). **Independently verified** on group elements and sample
points not used in the optimization: max residual 8.7×10⁻¹⁰. O is
confirmed genuinely orthogonal (OOᵀ=I) and proper (det=+1).

**Also fixed in passing:** the Fano→A_real step in Result 7 had taken
the real part of a complex intertwiner — valid only for the one
specific vacuum vector tested there, not in general (confirmed: the
transformed vacuum's imaginary part was exactly −6× its real part, a
coincidence of that specific vector, not a general property). Replaced
with a **direct, genuinely real** group-averaging intertwiner
Fano→A_real (real random seed, real output by construction),
independently verified equivariant to ~3×10⁻¹⁶. By Schur's lemma the
two constructions are necessarily proportional (the intertwiner space
for an irreducible real representation is 1-dimensional), so this
correction does not change any physical conclusion — it removes a
fragile step, not an error in the results already banked.

**Open end found this session, not yet resolved:** comparing the six
quartic invariants on *real* fields specifically reveals a **rank
asymmetry**. This correspondence's five (the sixth, antisymmetric,
vanishes identically on real fields): rank 4 — one linear relation.
King–Luhn's five I₁,I₂,I₃,I₄,I₆ (I₅ vanishes the same way): rank **3**
— two relations. A naive 6-parameter linear fit between the two sides
therefore cannot match well (~15% residual) — the correct comparison
is between their 3-dimensional real subspace and the corresponding
3-dimensional slice of this correspondence's 4-dimensional one, not a
same-size match. Not attempted here; a well-posed, concrete next step.

## Result 9 (2026-09-14, session 4) — the real cause found: wrong reference paper, not a typo; near-complete resolution

Three sessions (Results 7–8) searched for a rotation or a transcription
error to reconcile King–Luhn's Θ, Θ' (arXiv:0912.1344, eqs. 4.2–4.3)
with the basis built from Luhn-Nasri-Ramond's A^[6],B^[6]
(arXiv:0709.1447) via their S=VP transform. Every approach — index
reversal, exhaustive block-rotation pairings, 2×2 mixing matrices, a
full numerical SO(6) search, an exhaustive sign-flip search over
Θ'-terms — failed or landed on a mathematically real but ultimately
irrelevant structure (an eigenvalue of a connecting matrix equal to
exactly −b₇/b̄₇, a beautiful but, it turns out, beside-the-point
coincidence).

**The actual cause, found from the official arXiv LaTeX source of
0912.1344 (supplied by Selina/Ilya directly, sidestepping PDF
extraction entirely):** the text states explicitly "for χ given in the
real sextet basis of [King:2009mk]" — and **King:2009mk is King &
Luhn's own earlier paper, Nucl. Phys. B820 (2009) 269, arXiv:0905.1686,
not Luhn-Nasri-Ramond.** 0905.1686 builds its own explicit real sextet
generators 𝒮,𝒯,𝒰,𝒱 directly from the symmetric square of the triplet
representation (χᵢ~ψᵢψ'ᵢ etc., their eq. 4.1) — a genuinely different
construction, not related to the A,B/η-based one by any simple
rotation, which is exactly why three sessions of searching for one
found nothing.

**Rebuilding S,T,U,V explicitly from 0905.1686 eqs. 4.9–4.12 and
testing Θ,Θ' against them succeeds immediately and exactly** — no
search, no fix, nothing to correct. Both are covariant to machine
precision (≤1.8×10⁻¹⁴) across the full 168-element group. A fresh,
directly-verified intertwiner (Fano → this correct basis, equivariance
2.2×10⁻¹⁶) was built the same way as Result 7's.

**The payoff:** translating this correspondence's five real Fano
invariants through this intertwiner and comparing to King–Luhn's
I₁,I₂,I₃,I₄,I₆ gives a **perfect match — max fit error 7.8×10⁻¹⁶,
machine precision.** This is the first complete, successful
correspondence between the two invariant bases.

**Genuinely still open (at time of Result 9):** the complex/
antisymmetric piece (this correspondence's sixth invariant vs.
King–Luhn's I₅ — both vanish identically on real fields) does not show
fixed proportionality; the ratio varies across sample points
(std≈0.07 on a mean≈0.01), meaning I₅ most likely depends on a
*combination* of this correspondence's invariants, not a single one.
Resolved directly in Result 10, below, by sidestepping the translation
entirely.

## Result 10 (2026-09-14, session 4 continued) — κ₂=κ₃=κ₄+κ₅/√7 verified directly, independently

Rather than resolve the Result 9 I₅-translation gap, this checks
King–Luhn's central vacuum-alignment claim (§4.2.2, eqs. 4.24–4.26)
**directly against their own formulas** — since the claim is stated
entirely in terms of their own I₁..I₅, the Fano-side translation isn't
needed for this specific check.

**Method:** build f = (I₀+κ·I₁+κ'·(I₂+I₃+I₄)+κ''·(I₄−√7·I₅))/I₀ (their
eq. 4.24) from the now fully-verified Θ,Θ'; evaluate its 12-component
real gradient (∂/∂Re χᵢ, ∂/∂Im χᵢ) numerically at their stated χ_top
(eq. 2.10), for five different (κ,κ',κ'') choices spanning positive,
negative, and mixed signs.

**Result: the gradient vanishes at χ_top (≤1.9×10⁻⁸, floating-point
noise) for every (κ,κ',κ'') tested** — exactly matching King–Luhn's
claim that once their two relations (κ₂=κ₃=κ₄+κ₅/√7, built into this
I,I',I'' parametrization by construction) are imposed, χ_top is a
critical point for *any* values of the three remaining free couplings.
A smaller consistency check en route: I₁=0 and I₂=I₃ *exactly* at
χ_top (both structurally expected, neither assumed).

**This is a direct, from-scratch, independent confirmation of
King–Luhn's central result** — not a restatement, since Θ,Θ' were
re-derived and cross-checked against their own cited basis
(arXiv:0905.1686) rather than assumed correct. It does not (yet)
translate into this correspondence's own Fano-built κ-basis — Result
9's real-field match is exact and complete, but the I₅-translation gap
noted there remains open for that specific further purpose. For
directly verifying King–Luhn's own claim, as attempted here, it is not
needed.

## Result 11 (2026-09-14, session 4 continued) — χ_TB alignment also verified directly; both of King-Luhn's vacua now confirmed

Completes the direct verification by checking King-Luhn's OTHER stated
vacuum, χ_TB^[0]=(0,0,0,0,0,1) (their eq. 2.7, §4.2.1) — structurally
simpler than χ_top, since they claim first derivatives of *every*
individual Iₐ/I₀ vanish here, with no relations among the κ's needed.

**Gradient check:** confirmed directly — vanishes (≤2.8×10⁻⁸) for
arbitrary random (κ₁..κ₅), exactly as claimed.

**Both of their stated stability examples confirmed exactly:**
Example 1 (κ₁=5∈(−2,10), κ₂=1, rest 0) and Example 2
(κ₃=−0.03∈(−1/50,0), rest 0) each give a 12×12 real Hessian with
**exactly 2 zero eigenvalues** (the stated overall complex-scaling
freedom) **and 10 strictly positive** — genuine local minima in both
cases, matching their claims precisely.

**Full h₁..h₅ structural check, now exact:** revisited with the
correct 10-dimensional restriction (Re/Im of χ₁..χ₅, with χ₆ — the
scale direction — properly excluded, matching their own convention
exactly) rather than the full 12-real-dimensional space. All five
Hessian matrices match their stated h₁..h₅ (eqs. 4.12–4.16) to
finite-difference precision (max abs diff ≤2×10⁻⁵, i.e. exactly, not
merely in eigenvalue multiplicity) — resolving the earlier "labeling
difference" caveat completely. See `fano_chiTB_hessian_VERIFIED.py`.

**Together with Result 10, this completes an independent, from-scratch
confirmation of King–Luhn's entire Section 4 vacuum-alignment
program** — both χ_top and χ_TB, gradients and Hessians, using Θ,Θ',Ω
re-derived from their own cited source rather than assumed correct.

## What remains open — stated plainly

1. **Translating King–Luhn's I₅ into this correspondence's own
   Fano-built invariant basis** (Result 9) — needed only if one wants
   κ₂=κ₃=κ₄+κ₅/√7 expressed in Fano-combinatorial language; the
   relation itself is now directly verified against King–Luhn's own
   formulas (Result 10), independent of this translation.
2. **Whether "doublet=triplet degeneracy" and the stability inequality
   above are King–Luhn's actual conditions** (vs., e.g., a flat
   direction, or a comparison against their second required vacuum) is
   not established.
3. **Why the Result 6 coexistence window sits where it does** is not
   explained — found by interpolation between two exploratory points,
   not derived.

## Files

- `fano_sextet_six_invariants.py` — Results 1–2, self-contained (numpy
  only). Runs end to end with assertions; fails loudly if wrong.
- `fano_vacuum_hessian_degeneracy.py` — Result 3, self-contained
  (numpy + sympy). Finds the S4 vacuum, confirms 1+2+3_1, derives
  3κ_g2=2κ_mixed.
- `fano_v4_family_critical_points.py` — Result 4, self-contained
  (numpy + scipy). Builds V4, confirms the 3-dim family, finds and
  checks the 12 critical points.
- `fano_stability_inequality.py` — Result 5, self-contained
  (numpy + sympy). Derives the stability inequality and confirms it
  numerically, including the one genuinely stable point found.
- `fano_coexistence_region.py` — Result 6, self-contained
  (numpy + scipy). Confirms points A and B, interpolates between them,
  and locates + directly verifies the coexistence window where both
  vacuum types are simultaneously stable.
- `fano_intertwiner_found.py` — Result 7, self-contained (numpy only).
  Finds the intertwiner S by group-averaging (robust, unlike the
  earlier null_space attempt), verifies it on all 168 elements, and
  confirms the Fano S4 vacuum matches Luhn-Nasri-Ramond's own stated
  formula exactly, up to a fully-characterized diagonal η-twist.
- `fano_orthogonal_transform_found.py` — Result 8, self-contained
  (numpy + scipy). Finds O by direct optimization over SO(6),
  independently verifies it, fixes the Result-7 real-intertwiner step
  properly, and confirms (with assertions) the rank-4-vs-3 finding
  that motivates the next step.
- `fano_correct_STUV_basis_found.py` — Result 9, self-contained
  (numpy only). Builds King-Luhn's own S,T,U,V (arXiv:0905.1686),
  confirms Θ,Θ' covariance on all 168 elements, builds the correct
  intertwiner, and confirms (with an assertion) the perfect real-field
  invariant match.
- `fano_kappa_relation_VERIFIED.py` — Result 10, self-contained
  (numpy only). Directly, independently verifies King-Luhn's central
  vacuum-alignment claim (κ₂=κ₃=κ₄+κ₅/√7) by checking the gradient of
  their own potential f vanishes at their own stated χ_top, for
  several different coupling choices (all via assertions).
- `fano_chiTB_alignment_VERIFIED.py` — Result 11, self-contained
  (numpy only). Directly verifies the χ_TB alignment: gradient
  vanishing for arbitrary couplings, and both of King-Luhn's stated
  stability examples via full 12×12 Hessian eigenvalue checks (all
  via assertions).
- `fano_chiTB_hessian_VERIFIED.py` — Result 11 follow-up, self-contained
  (numpy only). The precise version of the h₁..h₅ structural check:
  correctly restricts to their own 10-dimensional (non-scaling)
  convention and confirms all five Hessians match their eqs. 4.12–4.16
  exactly (not just in eigenvalue multiplicity), resolving the
  "labeling difference" caveat from the first pass.
- `verify_fano_sextet.py`, `find_intertwiner.py`, `build_gl32_and_check.py`,
  `check_sym2.py` — earlier working scripts (including the two failed
  naive attempts — V⊕V* and Sym²(V), both reducible in characteristic
  2 — kept for the record, not because they succeeded).

---
END OF FINDING
