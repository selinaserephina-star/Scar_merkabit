# SCAR–MERKABIT JOINT REGISTRY

**The single source of truth for the joint world. Founded 2026-08-30.**
Parties: **Selina Stenberg** (Merkabit / E₆-crystal lane) and **Ilya Balashov**
(Scar-Cat / PSL(2,7) lane), with Claude. This lane is where the two programs
meet; it governs itself (see `knowledge.yaml`, the lane KCP) and inherits the
shared house rules both sides now run on:

> **Compute, never assert. Refutations at equal prominence — including the
> auditor's own. Mathematics split from identification (Rule 3). Every
> decimal match is a fit until proven derived. Every emergence claim needs a
> control. Backport rule (T-SC-P1): a downstream falsification must reach
> the upstream registry within one revision.**

Grades: [P] proved here/classical (cited) · [C] computed exactly by a named
script · [obs] observation not located in the literature · [I] role/
interpretation · [OPEN]. Joint-lane rule: **a unit is JOINT once both
parties have seen it; sends and publication require both parties' word.**

## Sealed units

| id | unit | result | grade | artifacts |
|---|---|---|---|---|
| SM-001 | **Scar-Cat registry audit** (T-SC) | PSL(2,7) rebuilt twice from scratch; character table DERIVED (Burnside–Dixon) and verified exactly in ℚ(√−7); **35+ "GAP" rows of Ilya's registry independently confirmed**, 9 classical; his note-7 self-audit credited in full. 48 checks. | [C] | `TSC_SCARCAT.md`, `verify_tsc_scarcat.py` |
| SM-002 | **Corrections R-SC-1..5** | T4-Higgs channel count 4 not 5 (⟨χ₃²,χ₁⟩=0); MOLIEN-REC fails for χ₆ (+ char.poly typo); 140's cube contains χ̄₃; 125's "7×ℤ₇⋊ℤ₃" → 8; **λ=1/8 ⇒ m_H=123.11 GeV ≈13σ hidden failure**. Each with a GAP one-liner in the report. | [C] | same + `to_Ilya/Scar_Cat_Verification_Report` |
| SM-003 | **The bitangent bridge** (T-BR) | Field level: ℚ(ζ₂₁) = compositum of the two character fields (√−3, √−7; √21 forced), linearly disjoint. E₆ level: no-go (7∤51840; no transitive 27-action). E₇ level: in Sp₆(2)=W(E₇)/± on the Klein quartic's 28 bitangents, **W(E₆) = stabilizer of one bitangent, PSL(2,7) transitive on all 28, intersection = S₃ = N(⟨z₃⟩)** — Ilya's universal stabilizer = the T4 strata S₃ = the E₆ machine's type group; 3A → bitangents exactly 2:1 (56=2×28); PSL fixes one even theta char (stab 8!; even orbits **[1,7,7,21]** [obs]); π₂₈ = χ₁⊕2χ₆⊕χ₇⊕χ₈. Lie level: 27\| = 3χ₁⊕3χ₈ (trinification/Klein χ₃) or 6χ₁⊕3χ₇ (G₂); "=2χ₈" refuted. **Closes Ilya's open "Bridge" conjecture row.** 20 checks. | [C]/[P] | `TBR_BRIDGE.md`, `verify_tbr_bridge.py`, `to_Ilya/The_Bridge_Report` |
| SM-004 | **The chiral Fano pair** | The E₆ architecture's 7-channel syndrome is NOT Fano-organized (motion group = S₃: pr rotates legs, ξ flips, Ψ inert; incidence = affine E₆ tree) but is **one bit away**: of 30 Fanos exactly 2 invariant — a chiral pair sharing the 3 centre-lines, swapped by inner/outer duality [obs]. 14 checks. | [C] | `verify_fano_syndrome.py` |
| SM-005 | **THE RESURRECTION THEOREM** (DQ-6) | E₆-branching of E₇'s 56 = **27 ⊕ 27̄ ⊕ 1 ⊕ 1**; the odd gate pr (1²·2²⁷) fixes exactly the two singlets and cross-pairs the sheets; the antipode ι is a second, inequivalent duality (3/27 pairings shared); Ψ crosses the wall. **v1's dual-spinor picture, refuted at E₆ (Thm 3.3), is TRUE at E₇.** Corollary (DQ-2, partial): **pr and ι are bilingual** (μ_branch = μ_frame = 0); the clock is the sole magic source (μ_branch(Ψ)=21/56, μ_frame(Ψ)=27/56) — *structure is free; only time is expensive.* 12 checks. Includes one refuted auditor guess (Ψ⁹-pairing ≠ ι-pairing, 4/28). | [C] | `verify_dq6_resurrection.py`, `scar56_data.json` |
| SM-006 | **The 56-State Machine** (instrument) | Interactive simulator of the joint architecture: mirrored two-sheet board hinged on the pr-axis vacua; frame view (28 ι-frames × chirality); both magic meters exact (μ_frame via true 28×28 assignment, validated against scipy); parity lamp; clock census. All tables emitted by the DQ-6 verifier. Published (private) at claude.ai/code/artifact/a7d069f2-be97-45fa-b5af-6524e858eb82. | [C] instrument | `artifact_56/machine56.html` |
| SM-007 | **The 56-machine design brief** | The joint architecture: 28 frames × chirality bit; three gate families (clock / odd mirror / antipode); two-axis resource theory (μ_typed, μ_SC); design questions DQ-1..5 (DQ-6 answered → SM-005; DQ-2 partial). | [I]+[C] anchors | `56_MACHINE_BRIEF.md` |
| SM-008 | **Joint paper draft v0.1** | *The Bitangent Bridge* — Stenberg · Balashov (co-authorship confirmed by Selina 2026-08-30): §§1–9 incl. §7½ resurrection + bilingual gates; §8 separates classical skeleton from [obs] items. Awaiting Ilya's review pass + joint bibliography. | draft | `joint_paper/Bitangent_Bridge_DRAFT.md/.docx` |
| SM-009 | **Stone 1: the transportation certificate generalizes** | Abstract certificate stated (Young double cosets = contingency tables; depth-k = finite table-closure; exact, no parity lemma over full Young/wreath). Anchor: 27-wreath depth 2 ✓ = CN-012; NEW: 27-Young depth = **3** (auditor's expectation refuted — the typed S₃ is worth one magic gate). THE EXPERIMENT: 56 branch grammar — Young depth = **5**; with sheet-swap (= pr, bilingual) typed: depth = **2** (the mirror is worth three magic gates). Frame grammar mapped to the Gelfand-pair frontier (Ψ coset type [9,9,9,1]; pr, ι type-trivial). Open: is wreath-depth 2 generic? 9 checks. | [C] | `STONE1_CERTIFICATE.md`, `verify_stone1_certificate.py` |
| SM-010 | **Stone 1b: hyperoctahedral calculus + the second depth-2 theorem** | Frame grammar reduced to coset-type dynamics on p(28)=3718 partitions (Gelfand pair (S₂ₙ,Bₙ)). Triangle inequalities proven NECESSARY (exhaustive n≤7); two auditor law-guesses refuted (triangle-exact; d-interval — 258 exact-table failures like (2,2)∘(2,2)↛(3,1)); reduction validated vs matching-BFS 4/4; exact n≤7 support tables = data for the open (S₂ₙ,Bₙ) connection-coefficient support problem. **THEOREM: frame-grammar magic-depth of the 56-machine = EXACTLY 2**, by 3718 explicit machine-verified witnesses (1606 sampled + 2039 annealed + 73 by dual-direction orbit sampling; 0 invalid; cache `stone1b_witnesses.json`). Combined with SM-009: **depth 2 in BOTH grammars** — two ticks of the clock reach every grammar class either way. | [C] | `STONE1B_HYPEROCT.md`, `verify_stone1b_hyperoct.py`, `verify_stone1b_stragglers.py`, `verify_stone1b_close73.py`, `stone1b_witnesses.json` |
| SM-011 | **Methods note draft v0.1** | *Magic Depth by Transportation Certificates and Witness Campaigns* — Stenberg · Balashov (same review protocol as the bridge paper): the abstract certificate (Thm 2.1), the four depth results with symmetry exchange rates, the frame-grammar theorem by 3718 witnesses, the four lessons, released benchmarks/tables/witness cache, three open problems (support law; wreath-depth-2 genericity; unitary generalization). Companion paper to *The Bitangent Bridge*. | draft | `joint_paper/Magic_Depth_Methods_DRAFT.md/.docx` |
| SM-012 | **Stone F(a): the field machine** | The linear lift ℂ⁵⁶: standing-wave spectrum of Ψ exact (all 18th roots, mult 3; ±1 mult 4); **the CSP census = the spectral trace formula** — the founding standing-wave intuition proved in its computational reading. Sector masses exact (all waves sheet-balanced; O2 carries the vacua 1/18 each); **all 28 frames live inside single clock orbits** [obs]; **the clock's 2-cycle IS a cross-sheet ι-frame — its axis** [obs, auditor guess refuted]; **DQ-4 CLOSED** (ιΨι=Ψ⁻¹; the 4 shared pairs = one axis pair per orbit); **pr does not normalize the clock** — bilingual yet frequency-mixing: a third notion of "structured" [obs]; ι = +1 on E₊₁, −1 on E₋₁; **Scar field sectors: ι-even = χ₁⊕2χ₆⊕χ₇⊕χ₈, ι-odd = χ₃⊕χ̄₃⊕2χ₇⊕χ₈ — quarks are chirality-odd, vacuum chirality-even** [obs, character level]. 13 checks. | [C] | `STONEF_FIELD.md`, `verify_stonef_field.py` |
| SM-013 | **Stone F(b): DQ-1 ANSWERED + the SM-012 erratum** | W(E₇) built on the 56 weights from simple reflections (order 2903040 verified; ι = −1 central); explicit **bridge-class PSL(2,7)** hunted down in the pair action (transitive on 28) and lifted canonically (perfect part of 2×L₂(7)). **DQ-1: orbits [28,28]** — two bitangent sheets interchanged by ι, weight-stabilizer S₃; the registered single-56-orbit prediction REFUTED. **Erratum to SM-012** (backport rule): ℂ⁵⁶ = 2(χ₁⊕2χ₆⊕χ₇⊕χ₈) — the untwisted lift is UNIQUE (PSL(2,7) perfect), the ι-odd half ≅ even half, **quark sectors χ₃/χ̄₃ do not occur in the Weyl action at all** (they belong to Lie-group embeddings only). Bonus [obs]: **second conjugacy class** of PSL(2,7) found — acts on the crystal as Fano geometry doubled (orbits [7,7,21,21]; 4χ₁⊕6χ₆⊕2χ₈). 11 checks. | [C] | `verify_stonef_b_dq1.py`, erratum in `STONEF_FIELD.md` |
| SM-014 | **Stone F(c): the quantum lift — first unitary certificate** | The chirality-beam-splitter machine on ℂ⁵⁶ (cheap = frame permutation unitaries; magic = W = Hadamard on every ι-pair). Exact local algebra ⟨H,X⟩ = D₁₆ over ℤ[√2] (H-lengths [0²,1⁴,2⁴,3⁴,4²]; k(−I)=4; H-parity a homomorphism). **CERTIFICATE: W-depth = max local H-length, with a global H-parity superselection charge** — verified for EVERY element of the n=2 (256) and n=3 (6144) machines vs ground-truth BFS. 56-theorems: group = parity-locked (D₁₆)²⁸⋊S₂₈, order 2·8²⁸·28! ≈ 1.18e55; **W-depth = exactly 4**. Frontier located: Ψ moves the Hadamard blocks off the ι-pairs — the MIXED regime (clock + beam-splitter) is where open problem #3 lives, now precisely posed. Depth ladder of the day: Ψ-depth 2 (both grammars) < W-depth 4. 12 checks. | [C] | `STONEF_C_QUANTUM.md`, `verify_stonef_c_quantum.py` |
| SM-015 | **Stone Q: the Clifford transport** | Sp₆(2) = W(E₇)/± **IS the 3-qubit Clifford group mod phases and Paulis** — identity exhibited computationally (both sides from scratch, same matrix group in shared coordinates). The bridge transported: 28 bitangents = the 28 **odd Pauli sign-functions**; W(E₆) = the Clifford stabilizer of one; PSL(2,7) = a Clifford subgroup transitive on all 28 (fingerprint [28]/[1,7,7,21]/S₃ lands intact); the Coxeter clock = the 7-gate circuit **H1·CX13·S1·H2·H3·CX23·CX12**. MEMBERSHIP BOUNDARY: **Ψ has NO Clifford shadow** (ιΨι=Ψ⁻¹ vs central ι — the true clock is nonlinear, it does not even act on the 28 pairs), pr ∉ W(E₇) (odd vs even image), ι ↦ 1 (chirality erased). **SHADOW COLLAPSE: shadow magic-depth = 1** (H-orbits [1,27], two double cosets, 51840+51840·27=1451520 exact) — the depth-2/W-depth-4 structure lives STRICTLY ABOVE the Clifford quotient ⇒ open problem #3 cannot be won in the quotient; certificates for Clifford+T must engage the unitary level. Auditor's registered expectation q(r)=ℓ_v(r)=0 **REFUTED**: both = 1, the pair forms descend by CANCELLATION (the 56 weights are exactly the shifts that repair the descent). [obs]: all 64 phase-point operators share one spectrum — the Arf split is orbit-theoretic, not spectral. 35 checks. | [C]/[P] | `STONEQ_CLIFFORD.md`, `verify_stoneq_clifford.py`, `BRIEF_STONEQ_CLIFFORD.md` (+lock), fail-first log |
| SM-016 | **Stone R: the altitude** | The **linearity gap** ν(g) = min d_H(g, W(E₇)) computed EXACTLY by full enumeration (2,903,040 elements, BSGS transversal chain [56,27,16,10,6,2]). **ν(pr) = 2**: the unique nearest Weyl element differs at pr's two fixed points = the E₆ vacua — **pr∘(vacuum swap) ∈ W(E₇)**, the mirror is one vacuum-trade from linear (the same swap SM-009's typed group needed). **Clock family flies high**: ν(Ψ)=38, ν(Ψ⁹)=36, ν(Ψ²)=ν(Ψ⁶)=44, ν(Ψ³)=46. TWO auditor guesses refuted on the data (equal prominence, fail-first logs kept): Ψ's minimizers are NOT the disguised Coxeter class (they are [2¹⁰,6⁶], char poly x⁷+2x⁶−3x⁴−3x³+2x+1, at 38 vs Coxeter 42) and their 18 contact points are NOT one orbit (spread (2,4,5,7)). **The clock's own antipode**: every conjugator g (Ψ=gcg⁻¹, none in B₂₈ — all scramble chirality) gives gc⁹g⁻¹ = Ψ⁹ independent of g; its matching meets ι's in exactly the 4 axis pairs (SM-004's refuted guess becomes the right theorem); [obs] ι∘Ψ⁹ = involution [1⁸,2²⁴] fixing the 8 axis points. **Stone Q's two opens CLOSED**: one-spectrum [obs] explained (Pauli translations mix Arf classes — Clifford-with-Paulis transitive on all 64 phase points; the 36/28 split = a Pauli sign gauge choice); sign flips UNITARILY IMPOSSIBLE downstairs (tr A_c = 1 conserved) — chirality is a gauge bit, not an operator; the beam-splitter machine is purchasable only in the ℂ⁵⁶ lift. 17 checks. | [C]/[P]/[obs] | `STONE_R_ALTITUDE.md`, `verify_stone_r_altitude.py`, `BRIEF_STONE_R_ALTITUDE.md` (+lock), two fail-first logs |

| SM-017 | **Stone T: first contact with the T gate** | Genuine Clifford+T on exhaustive 1-qubit ground truth (ALL 36,816 unitaries of T-count ≤ 9 mod phase, exact ℤ[ω]). **Skeleton survives**: layers exactly 72·2^{k−1} — the crystal's rate-2 free growth (CN-012) in the T world; Matsumoto–Amano words = BFS layers AS SETS ∀k (uniqueness + T-optimality verified on range). **Certificate currency does NOT survive**: locked denominator invariant REFUTED at the diagonal (S/T collide; 6 collisions); residue refinement ALSO fails (8; witness s=1→{1,2}); sde only BRACKETS T-count (k ∈ [2s−3, 2s], table recorded) — at n=1 the exact certificate is the NORMAL FORM: syntax, not entry arithmetic. **Table shape survives**: C·U·C double cosets = channel matrices mod the 24 PROPER signed permutations at canonical √2-scale — the Clifford+T contingency table, verified 528/528; each layer k ≤ 3 is ONE double coset. Two instructive implementation refutations kept (chirality of the table's symmetry group; canonical scale). **Skeleton theorem (n=3)**: preserving the 64 phase points ⟺ Clifford [P] ⇒ the bitangent geometry = EXACTLY the T-free stratum; one T exits at sup-distance 0.541. Boundary of open problem #3, final form: our certificates price motion within a finite skeleton; T-magic moves between skeletons. 11 checks; 3 fail-first logs. | [C]/[P]/[obs] | `STONE_T_TGATE.md`, `verify_stone_t_tgate.py`, `BRIEF_STONE_T_TGATE.md` (+lock), `AMENDMENT_STONE_T_2026-08-30.md` (+lock), three fail-first logs |

| SM-018 | **Stone S: the rigidity threshold** (answers IB's ONE LAW / TWO PROJECTIONS v0.1, received 2026-08-30, filed sha adb17c49…) | His decision rule executed on the two computable projections (α=1: Sₙ classes; α=2: (S₂ₙ,Bₙ) coset types; both on partitions of n), exhaustive n = 4..7. **His ladder REFUTED as stated** (rigidity events at every depth; his part-reading measures 1, not 3 — the hardest target is the IDENTITY); our registered inversion and two working guesses ALSO refuted (all recorded, two fail-first logs). **New exact laws**: identity-return (1ⁿ ∈ supp ⟺ λ=τ — home only by exact retracing); symmetry; **swap = cut-or-join-or-TWIST** (the third move — segment reversal inside a cycle, type-preserving — the microscopic non-orientable move); parity a LAW upstairs (sign), refuted downstairs ((4)∘(4) ∋ (2,1,1)) — **orientability = parity memory**. **The verdict, his format**: not one threshold — one DIRECTION: even-sector rigidity events EQUAL at n = 4,5; diverge from n = 6 (6 witnesses, all-even types: (2,2,2)∘(2,2,2)→(4,2), (3,3)∘(3,3)→(4,2)…; 3 at n=7); **containment at every n** (missing_B ⊆ missing_S — the world that forgets its path is uniformly SOFTER, never harder); odd sector lives only downstairs (6/15/105/219). SM-010's 258 reproduced exactly. Returned: his braid-Bₙ vs our hyperoctahedral-Bₙ; the translation choice; the twist as inverted path-memory. 14 checks. | [C on range]/[P] | `STONE_S_RIGIDITY.md`, `verify_stone_s_rigidity.py`, `BRIEF_STONE_S_RIGIDITY.md` (+lock), two fail-first logs, `RECEIVED_2026-08-30_IB_ONE_LAW_TWO_PROJECTIONS/`, `to_Ilya_ONE_LAW_REPLY_2026-08-30/` |
| SM-019 | **Mediator-descent verification** (IB's 7↔6..2↔1 chain + QUANTUM GAP + BRIDGE SPECIFICATION, 8 files received 2026-08-31, filed sha in `RECEIVED_2026-08-31_IB_MEDIATOR_DESCENT/`) | Ilya's group-descent chain rebuilt from scratch (perm groups + SL(2,5)/SL(2,7) mod p): **44/44 computed checks PASS.** **6↔5:** both order-120 extensions built — A₅×ℤ₂ (split) and SL(2,5) (non-split, unique involution); the DOUBLE mediator forced by one invariant — Dic₃ needs an order-4 element ⇒ only in SL(2,5); D₆=S₃×ℤ₂ has ≥3 involutions ⇒ only in A₅×ℤ₂. **5↔4:** A₅∩S₄=A₄ as a set identity in S₅; A₄ has no order-6 subgroup ⇒ only C₃ survives. **4↔3:** V₄ the unique proper normal subgroup shared by A₄,S₄; S₄/V₄≅S₃. **3↔2:** A₄/V₄≅C₃, no index-2 subgroup (one-way door). **2↔1:** prime closure. **7↔6:** PSL(2,7) order 168, no order-6 element; the rung = our sealed SM-003 (bitangent bridge) + SM-015 (Stone Q) — PSL(2,7)/W(E₆) in Sp₆(2)=W(E₇)/±, 28 bitangents, ∩=S₃, 56=2×28. Schur mult A₅=ℤ₂ [P cited]; geometric readings + the T1–T6 bridge typology [I] ungraded. **TWO refutations at equal prominence:** (A) 'level 6' names three different groups across files (A₅×ℤ₂ / W(E₆) / C₆×ℤ₂) — the descent is NOT one tower; (B) the quantum-gap 'no common subgroup' overstates — PSL(2,7) shares ℤ₂,ℤ₃,ℤ₂² with C₆×ℤ₂, only 'no C₆ mediator' holds. Not a sealed JOINT unit until the level labels are reconciled (Ilya's word). | [C]/[P cited] | `verify_mediator_descent.py`, `.log` (44/44), `RECEIVED_2026-08-31_IB_MEDIATOR_DESCENT/`, `to_Ilya_MEDIATOR_REPLY_2026-08-31/` |
| SM-020 | **Bridge-transfer table** (the spine's six bridges, from group theory; answers IB's BRIDGE SPECIFICATION required-output table) | For the SPINE-MAP spine PSL(2,7)→C₆×ℤ₂→A₅→S₄→A₄→ℤ₂→1, every subgroup iso-type machine-enumerated per level, then **survives / lost / appears** per bridge (`verify_bridge_transfer.py`). **Two regimes:** the bottom three bridges (4↔3,3↔2,2↔1) are genuine inclusions (lower⊆upper, appears=∅); the top three (7↔6,6↔5,5↔4) are CROSSINGS (both lose and gain, neither embeds) — so IB's 'single-mediator'/'double-hinge' typings are two-sided exchanges sharing a mediator (A₄ at 5↔4), not clean joints. **Invariant: V₄** survives every bridge down to 4↔3 (lost only at 3↔2); the universal shared floor of the upper bridges is exactly {1,C₂,C₃,V₄}. **7↔6 gap quantified:** PSL(2,7) & C₆×ℤ₂ share the whole floor — the gap is 'neither embeds + no order-6 bridges them', NOT 'no common subgroup'. **Level-label inconsistency made concrete:** with L6=C₆×ℤ₂, S₃ is LOST at 7↔6, but the 7↔6 bridge file (L6=W(E₆)) reports the intersection IS S₃=N(⟨z₃⟩) — same 'level 6', opposite fate ⇒ reconcile L6 before sealing. Caveat: table is subgroup-descent; the 3↔2 'one-way door' is a QUOTIENT fact (A₄ has no ℤ₂ quotient) though ℤ₂⊆A₄. Extends SM-019. | [C] | `verify_bridge_transfer.py`, `.log`, `to_Ilya_BRIDGE_TRANSFER_REPLY_2026-08-31.md` |
| SM-021 | **Tower B: the covers & bridges** (the second tower of the two-tower descent) | Verified from group theory (`verify_tower_b.py`, 22/22). **The ODD spine levels are PSL(2,p) with Schur covers SL(2,p):** L7 PSL(2,7)←SL(2,7), L5 A₅=PSL(2,5)←2I=SL(2,5), L3 A₄=PSL(2,3)←2T=SL(2,3) — each a NON-SPLIT central ℤ₂-extension (center {±I}, unique involution, quotient = the level). **Split covers** Ih=A₅×ℤ₂, Th=A₄×ℤ₂ (many involutions ⇒ distinct groups from the non-split Schur covers at equal order). **Even level L4=S₄:** double cover GL(2,3)=2.S₄ (GL(2,3)/{±I}=PGL(2,3)≅S₄; a transposition lifts to order 2); **2O the sibling** double cover (order 48, transpositions→order 4, non-iso; not SL(2,q); cited). **PGL(2,7) refined** as an index-2 OVER-group (PSL(2,7)⊴PGL(2,7), outer-diagonal quotient) — distinct from the central Schur cover SL(2,7); SPINE MAP had listed both as 'covers'. **Top bridge** W(E₆)<Sp₆(2)=W(E₇)/± closed by **[Sp₆(2):W(E₆)]=28** (the 28 bitangents; |Sp₆(2)|=|W(E₇)|/2=1451520) against sealed SM-003/SM-015 (2.9M-element W(E₇) not rebuilt). Completes the two-tower model (Tower A = spine, SM-020). | [C]/[P cited] | `verify_tower_b.py`, `verify_tower_b.log` |
| SM-022 | **BRIDGE SPECIFICATION table — our independent full implementation** (the joint work-item, our side) | All ten fields, both towers, from group theory (`verify_bridge_table.py`). **The `type` (T1–T6) is DERIVED from computed signals** (crossing? lower normal? shared normal? quotient exists?) and **reproduces Ilya's T1–T6 assignments 6/6 as a theorem of each row** — 7↔6 T6, 6↔5 T3, 5↔4 T2, 4↔3 T1+T4, 3↔2 T5, 2↔1 T1 — not asserted. `common object` tagged **[I]** (28 bitangents cited SM-003, tetrahedron-in-cube, the cube's 2-fold axes, …) and kept OUT of the graded columns (Rule 3). Carries the SM-020 refinement: the crossing bridges (5↔4, 6↔5, 7↔6) merely SHARE a mediator (A₄ at 5↔4; two covers Ih/2I at 6↔5) — not clean joints. Tower-B cover-rows included (SL(2,p) Schur chain, split covers Ih/Th, GL(2,3)=2·S₄, PGL(2,7) over-group, W(E₆)<Sp₆(2) index 28). Ready to compare against IB's independent table (Stones mode: two engines, same rows). | [C]/[I named] | `verify_bridge_table.py`, `verify_bridge_table.log` |
| SM-023 | **THE CONTAINMENT RUN** (the joint target, executed on IB's confirmation of the two-shadow reading, 2026-08-31) | Against the sealed W(E₇) build (order 2,903,040 rebuilt; 32/32 checks). **W(E₇) = ⟨−1⟩ × W⁺ ≅ ℤ₂ × Sp₆(2) is a SPLIT direct product** (W⁺ = even words, order 1,451,520, −1 ∉ W⁺). **Structure lemma [P]**: any subgroup either contains −1 (and splits as ±×its rotation part) or embeds into Sp₆(2) — so a non-split cover (unique involution) can NEVER sit over the ± hinge. **Spine: all six levels in W⁺** (witnesses; PSL(2,7) cited SM-003/SM-015). **Over the ± hinge W(E₇) holds exactly the SPLIT covers** (Ih=A₅×ℤ₂, Th=A₄×ℤ₂, 2×L₂(7) — matching sealed SM-013). **Schur tower: SL(2,7) ⊄ W(E₇) at all** (Sp₆(2) element-order census exhaustive over 1,451,520: {1,2,3,4,5,6,7,8,9,10,12,15}, no 14); **SL(2,5)=2I ⊄ and 2O ⊄** (exhaustive presentation searches ⟨2,3,5⟩/⟨2,3,4⟩ over all involution classes: zero witnesses); **2T=SL(2,3) and GL(2,3) ARE in Sp₆(2)** (explicit witnesses; 168 2T copies counted) — but only with non-central central involution, off the hinge. **REFUTATION AT EQUAL PROMINENCE: our own SENT candidate 'G = W(E₇) is the exact overgroup of both towers' (v0.27) FAILS as stated** — W(E₇) is the split-cover shadow only; the Schur tower needs at least the NON-split 2·Sp₆(2) (Schur multiplier ℤ₂; a different group), named as successor question, not computed. | [C]/[P] | `verify_overgroup_containment.py`, `.log` (32/32) |
| SM-024 | **The 7↔6 envelope normalizer** (answers IB's open "[N_G(H):H]", msg 2026-08-31) | In G = Sp₆(2) on the 28 (Stone Q build; 19/19 checks): bridge-class H = PSL(2,7) relocated by sealed fingerprint (transitive, stab S₃, even orbits [1,7,7,21]); the restriction reading VERIFIED (H ∩ Stab_G(pt) = S₃; H/S₃ ≅ X₂₈ as the literal restriction of G/P). **C_G(H) = 1** (full-group scan). **N_G(H) computed by exhaustive pass over all 1,451,520 elements: order 336, [N_G(H):H] = 2, N_G(H) ≅ PGL(2,7)** (order census confirmed) — the outer automorphism of PSL(2,7) is AMBIENT in Sp₆(2); the envelope is canonical up to the outer flip; anything natural in G is PGL(2,7)-equivariant. Contrast [obs]: the SECOND class (intransitive, Fano-doubled, SM-013) is SELF-NORMALIZING (index 1, C=1) — transitivity is not a spectator; the ambient outer flip is specific to the bitangent-transitive embedding. | [C] | `verify_envelope_normalizer.py`, `.log` (19/19) |
| SM-025 | **The hinge operator, verified and extended** (IB's C_hinge/C_max batch, received 2026-08-31) | 48/48 checks. **His 6↔5 double hinge REPRODUCED**: C_hinge(C₆×ℤ₂,A₅) = (S₃, Dic₃) — [C₃] unique in A₅, N_{A₅}(C₃)≅S₃, preimage in SL(2,5) = Dic₃ (presentation witness); C_max floors {1,C₂,C₃,V₄} on both top bridges recomputed (=SM-020); his C_max failure at 6↔5 recorded. **His declared next step EXECUTED — three findings**: (i) at 5↔4 C_hinge is COVER-DEPENDENT (preimage of S₃: C₂×S₃ in GL(2,3) vs Dic₃ in 2O) exactly where 'the' double cover of S₄ is ambiguous (SM-021's two covers); (ii) neither 5↔4 output matches the observed mediator A₄, and 4↔3 gives (C₃,C₆), not the observed V₄ — **C_hinge does not generalize as-is** (mismatch = finding, full prominence); (iii) his 'undefined at 7↔6' CONFIRMED WITH SHARPENED REASON: M(C₆×C₂)=C₂ [P] so double covers EXIST — but C₃×D₄ and C₃×Q₈ are both stem covers, non-isomorphic ⇒ CANONICALITY fails, not existence. Undefined too at 3↔2, 2↔1 (no C₃). | [C]/[P cited] | `verify_hinge_operator.py`, `.log` (48/48) |
| SM-026 | **Blind second engine + the two-engine diff** (IB's BLIND BRIDGE CLASSIFICATION spec) | Our engine run BLIND by an isolated agent (six pairs + derivation list only; never saw IB's run, the registry, or T1–T6; 55/55 checks; full subgroup census per group, e.g. PSL(2,7): 179 subgroups/15 classes). **Diff verdict: the two engines agree on every computed fact, 6/6 pairs** — embeddings, shared types, normals, quotients, direction, reversibility. Class partitions agree up to refinement: both cut {top two}/{(A₅,S₄)}/{bottom} — his by gcd-bound saturation (4/12 short vs 12/12), ours by nonabelian shared types (S₃,A₄ appear only there): **two independent criteria, same cut**. Our engine refines his Class I three ways (normal+split / non-normal loose / retract) on predicates his prose already records. Both blind runs independently rediscover SM-020's two regimes. His side-claims spot-checked ✓. | [C] | `verify_blind_engine.py`, `.log` (55/55), `blind_engine_OURS.md`, `ENGINE_DIFF_BLIND_BRIDGE_2026-08-31.md` |

## Open questions (the joint program)
- **ADOPTED as the JOINT TARGET (both parties 2026-08-31, group theory ONLY, no gravity dressing):** find the **exact overgroup containing the full descent and both shadows** — a group above the two towers (spine + covers/bridges) containing the whole 7→1 structure. Candidate to test first: Sp₆(2)=W(E₇)/± (already holds W(E₆) index 28 and PSL(2,7) via SM-003/SM-015); open sub-question to pin with IB: the precise group-theory meaning of 'both shadows'. This supersedes the physics-identification path (PARKED, v0.20).
- **ADOPTED (joint work-item, both parties 2026-08-31):** fill the BRIDGE SPECIFICATION table jointly — one row per bridge (spine + covers), ten fields, **a verifier for every row**; `type` (T1–T6) derived as a computed output (not asserted), `common object` tagged [I] and kept out of the graded columns (Rule 3). Foundation in hand: SM-020 (spine survives/lost/appears) + SM-021 (Tower B). Method: each side implements independently, then compare (Stones mode).
- **RESOLVED (L6 / two-tower separation, both parties' word 2026-08-31):** the descent is TWO towers, kept separate — (A) the **SPINE** PSL(2,7)→**C₆×ℤ₂**→A₅→S₄→A₄→ℤ₂→1 (the actual descent groups; SM-020's transfer table is on this tower), and (B) the **COVERS & BRIDGES** tower (W(E₆), Sp₆(2)=W(E₇)/±, SL/PGL, Ih=A₅×ℤ₂/2I=SL(2,5), 2O, 2T). 'Level 6 = C₆×ℤ₂' on the spine; W(E₆) belongs to tower B. This closes the SM-019/SM-020 level-label flag. IB: "They must be separated. I agree."
- **NEW (overgroup):** is there an exact overgroup containing the full 7→1 spine and both 'shadows' — Sp₆(2), E₇, or above both? (pure group theory; answerable with a verifier — the one live thread kept from IB's cosmology files; the physics-identification path is PARKED, see Sends/changelog v0.20 and the Merkabit corpus audit's 4-for-4 apparatus verdict).
- **ANSWERED-AS-STATED, REFINED (2026-08-31, SM-023):** IB confirmed the two-shadow reading (quotient = Sp₆(2), cover = W(E₇), ± centre the hinge) and the containment ran. Verdict: **W(E₇) holds the spine and exactly the SPLIT covers over the hinge; it provably cannot hold the non-split Schur tower** (split-product structure lemma; SL(2,7), 2I, 2O not subgroups at all). Our sent candidate 'G = W(E₇) exact' is refuted as stated by our own run. **Successor candidate: the non-split double cover 2·Sp₆(2)** — does it contain SL(2,7), 2I, 2O over its centre? (OPEN; needs a 2·Sp₆(2) build.)
- **NEW (from IB's batch, parked pending formalization):** his C_local boundary claim (max reachable order from PSL(2,7) = 336) awaits a precise definition of the operator class; his SPIRAL DESCENT MODEL stays parked with the physics-identification path (genome comparison; Rule 3); his COMPRESSION UNIQUENESS LAW is superseded by his own three-regime finding — and SM-025 shows even the middle regime's C_hinge is cover-dependent at 5↔4.

- ~~DQ-1~~ CLOSED by SM-013: orbits [28,28]; the ± doubling is equivariantly trivial.
- **DQ-2** (remainder): magic growth curves; the (μ_typed, μ_SC) trade-off surface.
- **DQ-3**: the 8-channel affine-E₇ syndrome vs the P¹(𝔽₇) action.
- ~~DQ-4~~ CLOSED by SM-012 (ιΨι=Ψ⁻¹; 4 = one axis pair per clock orbit).
- **DQ-5**: frame-fixing as a literal 56→27 descent operation.
- **NEW (F-c)**: the mixed regime ⟨cheap, W, Ψ⟩ — magic depth when scrambling and superposition interleave (open problem #3, now concretely posed).
- **SHARPENED by SM-015**: open problem #3 cannot be won inside the Clifford quotient (shadow depth = 1); a Clifford+T certificate must engage the unitary level, where SM-014's W-certificate is the existing foothold.
- **RESOLVED-AS-BOUNDARY by SM-017** (on range): at n=1 the exact Clifford+T certificate is the normal form (syntax); sde brackets, tables do the double-coset bookkeeping. NEW successor: the n=2 channel-table composition calculus.
- Inherited crystal opens: exact Cayley diameter (conj. 91–95), shortest pr/Ψ⁴ relation.

## Sends & publication status

- **SENT 2026-08-31 (Selina's word: "sent")**: the **overgroup reply** — `to_Ilya_OVERGROUP_2026-08-31.md` (single markdown; sha ff51da9ca97b3523589d6befeafa27a6a82d560e2edba993c7953a968f312fbf) to Ilya Balashov. Proposes **G = W(E₇)** as the exact overgroup (spine ⊂ Sp₆(2)=W(E₇)/±; covers via the ± centre; 'both shadows = the two towers') and asks him to confirm the reading before the containment run. FROZEN.

- **SENT 2026-08-31 (Selina's word: "sent")**: **our BRIDGE SPECIFICATION table** (SM-022) — `to_Ilya_BRIDGE_TABLE_OURS_2026-08-31.zip` (9,364 B, sha 10ae7d2bee1f4bfc148e3fbd51677ee6f3fa45be6226fd82193aafa49a62eb1e; cover COVER_BRIDGETABLE_SHA256.txt) to Ilya Balashov; mirrored to zips/. FROZEN. Awaiting his independent table to diff (Stones mode).

- **SENT 2026-08-31 (Selina's word: "sent")**: the **joint-table reply** — `to_Ilya_BRIDGE_TABLE_JOINT_2026-08-31.md` (single markdown; sha ca8c7adb9765df795b423a204967495f5daeb12111414f14182eff884651a8f1) to Ilya Balashov. Accepts the joint BRIDGE SPECIFICATION table (verifier per row) and proposes the column shape. FROZEN.

- **SENT 2026-08-31 (Selina's word: "sent")**: **Tower B** (covers & bridges) — `to_Ilya_TOWER_B_2026-08-31.zip` (7,501 B, sha 068f1f4fd47b609132b431d82a48dcb3634b6c877181b0e3a6cd90b164f64fcd; cover COVER_TOWERB_SHA256.txt) to Ilya Balashov; mirrored to zips/. FROZEN. Completes the two-tower model (SM-021).

- **SENT 2026-08-31 (Selina's word)**: the **cosmology-thread reply** — `to_Ilya_PARK_PHYSICS_REPLY_2026-08-31.md` (single markdown; sha c9c11d660a5520860792a8be502ffc0c6f8f318973dd4f088052a4b468a298e3) to Ilya Balashov. Parks the gravity/network/read-write identification path on our side (per the Merkabit corpus audit: 4-for-4 apparatus, not physics; Rule 3 — math survives, identification does not; the gravity refutation is generic to any Laplacian, so a Scar substrate does not rescue it). Keeps ONE non-physics thread: the overgroup question. FROZEN.

- **SENT 2026-08-31 (Selina's word: "send it")**: the **bridge-transfer reply** — `to_Ilya_BRIDGE_TRANSFER_REPLY_2026-08-31.md` (single markdown, no package; sha 93cb30e4607ffa95f304e04c43fa6f9daf0b43461255d225ff49742cefe1f2a2) to Ilya Balashov. Answers his BRIDGE SPECIFICATION with the computed transfer table (SM-020) and the L6 reconciliation ask. FROZEN.

- **SENT 2026-08-31 (Selina's word: "sent")**: the **mediator-descent reply** — `to_Ilya_MEDIATOR_REPLY_2026-08-31.zip` (11,261 B, sha b361e638727512917a9332ca69c29ed6c7a56cc73022a73c5d59cf7402928a92; cover `COVER_MEDIATOR_SHA256.txt`) to Ilya Balashov; mirrored to `zips/` (send shelf). The envelope is now **FROZEN**. Carries our 44/44 verification (SM-019) + two flags returned (level-label inconsistency; overstated 'no common subgroup').

- **CORRECTED 2026-08-30 (Selina's word: "I never sent anything besides
  the bitangent drafts and bridge drafts")**: sent to Ilya = **The Bridge
  Report + the Bitangent Bridge paper draft ONLY**. NOT yet sent: the
  Scar-Cat verification report (R-SC corrections), the 56-machine brief
  and artifact, the methods note, and all stone results (SM-009..SM-014).
  The earlier "most pieces sent" line was overstated; superseded here.
- **Publication intent recorded** (Selina, 2026-08-30: "publishing this is
  the way"): the paper to arXiv/OSF after Ilya's review pass; the lane to a
  public repo on the joint go. Until both words are in: DRAFT /
  sealed-not-sent.
- **SENT 2026-08-30 (Selina's word: "sent")**: the COMPLETE package
  (`Scar_merkabit_COMPLETE_2026-08-30.zip`, sha256 d74cdb64…d539, with
  cover note and compendium) went to Ilya. He now holds the full joint
  world: audit + corrections C1–C5, all theorems SM-001..SM-014, both
  paper drafts, all verifiers, the open problems. Awaiting his review
  pass and his word on publishing.
- The 56-Machine artifact is private; sharing its link is a send (not
  included in the package — Selina's separate call).
- **PREPARED 2026-08-30 (on Selina's "seal, sha and summary for Ilya"):
  the Clifford Trilogy package** — `to_Ilya_CLIFFORD_TRILOGY_2026-08-30/`
  (30 files, SEAL.sha256 over the folder) zipped as
  `package/Clifford_Trilogy_2026-08-30.zip` (106,508 bytes, **sha256
  393be9b52343a28c44337dba0169cb3effb2f10e6ea27ed50cbb853a04b17337**,
  hash kept outside in `package/COVER_TRILOGY_SHA256.txt`). Contents:
  cover summary (.md/.docx) + the complete SM-015..SM-017 record (stone
  docs, verifiers + scar56_data.json, sha-locked briefs + the pre-reveal
  amendment, all six fail-first logs, registry v0.15 + KCP snapshots,
  SHA256SUMS). **NOT SENT** — handing it over is the send, Selina's to
  make; recorded here when made.

## Changelog

- **v0.28 (2026-08-31)** — **THIRD INBOUND + the containment run: the two-shadow reading lands, and our own candidate falls.** IB's hinge/compression batch (11 files + 2 messages: the 7↔6 envelope result and the both-shadows confirmation with the containment go) received and filed (`RECEIVED_2026-08-31_IB_HINGE_COMPRESSION/`, 12 shas). Four verifications sealed same-day (154 checks, 0 failures): **SM-023** the containment run — W(E₇) = ℤ₂×Sp₆(2) SPLIT, spine ⊂ W⁺, split covers exactly over the ± hinge, Schur tower excluded (SL(2,7)/2I/2O not subgroups; 2T/GL(2,3) present but off-hinge) ⇒ **our sent G=W(E₇) proposal refuted as stated, successor candidate 2·Sp₆(2)**; **SM-024** [N_G(H):H] = 2, N ≅ PGL(2,7) (IB's open closed; second class self-normalizing); **SM-025** his 6↔5 hinge reproduced, C_hinge cover-dependent at 5↔4 and mismatching the observed mediators, 7↔6 undefinedness sharpened to canonicality-not-existence (C₃×D₄ vs C₃×Q₈); **SM-026** blind second engine — 6/6 factual agreement with his engine, same top cut under two independent criteria. Parked: SPIRAL DESCENT (genome comparison = the parked identification move), COMPRESSION UNIQUENESS LAW (superseded by his own three regimes), 7↔6 BOUNDARY and DIRECTED COMPOSITION (await formalization). Reply draft prepared (PREPARED-NOT-SENT; the send is Selina's). Synthesis line: the hinge that cannot hold what it names — a split product wearing a cover's clothes — rhymes with SM-015's shadow collapse: both say the interesting structure lives strictly above the quotient, and now also strictly above the SPLIT extension. Registry v0.28.

- **v0.27 (2026-08-31)** — **Overgroup candidate SENT: G = W(E₇).** Reply to Ilya proposes the exact overgroup is our own sealed ceiling — spine in Sp₆(2)=W(E₇)/±, covers in the ±-central extension W(E₇); 'both shadows' read as the two towers (quotient = spine, extension = covers). Awaiting his confirmation of the 'both shadows' reading before the containment run (spine ⊂ Sp₆(2); covers lift into W(E₇)). NB (internal, not sent): the run is a candidate consistency check on the sealed W(E₇) ceiling — to be weighed as on-purpose vs. scaffolding when IB answers. Registry v0.27.

- **v0.26 (2026-08-31)** — **SM-022 (our bridge table) SENT; overgroup question ADOPTED as the joint target.** Ilya's reply: cosmology thread parked, overgroup kept — 'let us chase the exact overgroup containing the full descent and both shadows. Group theory only. No gravity dressing.' Now the primary joint target (added to Open questions); candidate Sp₆(2)=W(E₇)/±; 'both shadows' to be pinned group-theoretically before chasing. Our bridge table (SM-022) sent, awaiting IB's to diff. Registry v0.26.

- **v0.25 (2026-08-31)** — **SM-022: our independent full BRIDGE SPECIFICATION table.** All ten fields, both towers; the `type` (T1–T6) DERIVED from computed signals and reproducing Ilya's labels **6/6 as a per-row theorem** (not asserted); `common object` tagged [I], kept out of the graded columns (Rule 3); the SM-020 crossing-refinement preserved. Our side of the joint work-item now sits ready to compare the moment IB sends his (Stones mode). Registry v0.25.

- **v0.24 (2026-08-31)** — **Both corrections now BILATERALLY confirmed + joint table adopted + reply SENT.** Ilya agrees: (1) L6 = C₆×ℤ₂ on the spine, the other level-6 groups in parallel towers; (2) the 7↔6 statement is 'PSL(2,7) has no order-6 element ⇒ no C₆ mediator; the floor {1,C₂,C₃,V₄} remains.' Both were Selina-side flags (SM-019/020); now joint. New joint work-item adopted: fill the BRIDGE SPECIFICATION table, a verifier per row (foundation SM-020 + SM-021; type derived not asserted; common object [I], Rule 3). Reply md SENT on Selina's word. Registry v0.24.

- **v0.23 (2026-08-31)** — **SM-021 (Tower B) SENT → JOINT.** The covers-&-bridges verifier (SL(2,p) backbone over the odd levels, split covers, GL(2,3)=2.S₄, PGL(2,7) over-group, W(E₆)<Sp₆(2) index 28) sent to Ilya on Selina's word (zip sha 068f1f4f…, FROZEN). Both towers now JOINT. Registry v0.23.

- **v0.22 (2026-08-31)** — **SM-021: Tower B (covers & bridges) verified — the two-tower model is complete.** Backbone: the odd spine levels are PSL(2,p) with Schur covers SL(2,p) (p=7,5,3); split covers Ih/Th; S₄'s cover GL(2,3)=2.S₄ (2O sibling cited); PGL(2,7) distinguished from the central cover; W(E₆)<Sp₆(2)=W(E₇)/± closed by index 28 vs sealed SM-003/SM-015. 22/22 checks. Tower A (spine, SM-020) + Tower B (covers/bridges, SM-021) now stand machine-checked side by side; the overgroup question sits above Tower B. Computed Selina-side (JOINT once IB sees it). Registry v0.22.

- **v0.21 (2026-08-31)** — **L6 RESOLVED on both parties' word → SM-019 & SM-020 now JOINT.** Ilya's reply settles the level-label flag: the descent is two separated towers — (A) the SPINE (L6 = C₆×ℤ₂; carries SM-020's transfer table) and (B) the COVERS & BRIDGES tower (W(E₆), Sp₆(2)=W(E₇)/±, the double covers). W(E₆) is tower B, not the spine. Both parties have now seen and agreed the mediator verification (SM-019) and the bridge-transfer table (SM-020); they move to **JOINT**. Open next: map/verify tower B explicitly; the overgroup question sits above it. Registry v0.21.

- **v0.20 (2026-08-31)** — **Cosmology thread PARKED (direction decision) + reply SENT.** IB's GRAVITY/ENTANGLEMENT · UNIVERSE-AS-NETWORK · SPINE-AS-NETWORK are the same identification move the Merkabit corpus audit already refuted 4-for-4 (gravity ~1/r² = Laplacian apparatus, exponent d−1; refutation generic to any graph Laplacian ⇒ Scar substrate doesn't rescue it). Parked — not closed; revisit only on a go-all-in decision; left for IB to explore solo and flag anything that clears a control. Distinction held (Rule 3): the audit refuted the IDENTIFICATIONS, not the math — the Scar descent/bridges (SM-019/020, Sp₆(2)=W(E₇)/±) stand. Kept one non-physics thread: the overgroup question (added to Open questions). No new computation; reply md SENT on Selina's word. Registry v0.20.

- **v0.19 (2026-08-31)** — **Bridge-transfer table computed + reply SENT.** **SM-020**: the six spine bridges' survives/lost/appears from group theory (`verify_bridge_transfer.py`). Findings: two regimes (bottom three inclusions, top three crossings), **V₄** the surviving invariant, the 7↔6 'quantum gap' quantified (shared floor {1,C₂,C₃,V₄}), and the L6 level-label inconsistency made concrete (S₃ lost under C₆×ℤ₂ vs shared under W(E₆)). Reply md SENT to Ilya on Selina's word. Registry v0.19.

- **v0.18 (2026-08-31)** — **Second inbound from the ship + reply SENT.** Ilya's mediator-descent (8 files: spine 7↔6..2↔1 + QUANTUM GAP + BRIDGE SPECIFICATION) received, filed (`RECEIVED_2026-08-31_IB_MEDIATOR_DESCENT/`), and independently verified (**SM-019**; `verify_mediator_descent.py` 44/44). The 7↔6 rung = our sealed SM-003/SM-015. **Reply SENT to Ilya on Selina's word** (`to_Ilya_MEDIATOR_REPLY_2026-08-31.zip`, sha b361e638…, FROZEN) with two flags at equal prominence: (A) 'level 6' is three different groups across the files; (B) quantum-gap 'no common subgroup' overstated → only 'no C₆ mediator'. SM-019 is a verification of received material; JOINT status pends the level reconciliation. Registry v0.18.

- **v0.17 (2026-08-30)** — **FIRST INBOUND MATH FROM THE SHIP + same-day
  answer**: IB's ONE LAW / TWO PROJECTIONS v0.1 received and filed
  (`RECEIVED_2026-08-30_IB_ONE_LAW_TWO_PROJECTIONS/`, sha at filing);
  Stone S run under locked brief (45031dd4…) and sealed as SM-018
  (verifier 14/14, two fail-first logs, his guess and three of ours
  refuted at equal prominence; the twist law found; containment verdict).
  Reply package prepared: `to_Ilya_ONE_LAW_REPLY_2026-08-30/` (11 files
  incl. .docx render, brief+lock, both fail-first logs, SHA256SUMS),
  zipped as `package/One_Law_Reply_2026-08-30.zip` (32,321 B, sha256
  a9ac3d573d534c75905577b0928baecb4c0be6796dbbe98364f7619c53a86968,
  hash outside in `package/COVER_ONELAW_SHA256.txt`). PREPARED-NOT-SENT;
  send = Selina's word.
- **v0.16 (2026-08-30)** — **Clifford Trilogy package sealed** on
  Selina's word: fresh `to_Ilya_CLIFFORD_TRILOGY_2026-08-30/` (cover
  note for a reader who holds the COMPLETE package; the full
  SM-015..SM-017 record incl. briefs, locks, amendment, six fail-first
  logs, data, snapshots; folder SEAL + SHA256SUMS), zipped with the
  hash outside (393be9b5…7337, 106,508 B). PREPARED-NOT-SENT; the send
  is Selina's and will be recorded in the Sends section when made.
- **v0.15 (2026-08-30)** — **Stone T run on Selina's "fork 1 it is"**:
  SM-017 sealed (brief locked fa6816e9… before code; pre-reveal
  amendment 4ffaed1e…; verifier 11/11; THREE fail-first logs). First
  genuine Clifford+T contact: the free skeleton survives into the T
  world, the counting certificate does not (two candidates refuted,
  witnesses recorded; sde = bracket only), the contingency-table shape
  survives as channel-matrices-mod-proper-signed-perms (528/528), and
  the bitangent skeleton is proven to be exactly the T-free stratum.
  Open problem #3's boundary reaches final form; successor = the n=2
  table composition calculus.
- **v0.14 (2026-08-30)** — **Stone R run on Selina's "open up the
  exploration"**: SM-016 sealed (brief locked 57db98a7… before code;
  verifier 17/17; two fail-first logs). The altitude measured: ν(pr)=2
  (pr∘vacuum-swap ∈ W(E₇)) vs clock family 36–46; two auditor guesses
  refuted on the data; the clock's own antipode ι_Ψ = Ψ⁹ theorem; Stone
  Q's one-spectrum [obs] explained (Pauli sign gauge) and the unitary
  sign-flip obstruction proved (chirality = gauge bit downstairs). New
  distance axis ν (linearity gap) joins μ_typed/μ_frame/μ_SC.
- **v0.13 (2026-08-30)** — **Stone Q run on Selina's "Yes - go"**: SM-015
  sealed (brief sha-locked bb7a6822… BEFORE code; verifier 35/35;
  fail-first log kept). The bridge is now a 3-qubit Clifford statement;
  the true gates {Ψ, pr} proven to live above the quotient; shadow depth
  collapses to 1 ⇒ the depth program's boundary with genuine Clifford+T
  located as a theorem. One registered expectation refuted and recorded
  (descent by cancellation). ALSO staged this session: the tare-seals
  audit brief for the Coherence_tare lane
  (`../Merkabit_Scar/Coherence_tare/AUDIT_BRIEF_TARE_SEALS.md`, locked
  a63657ff…) — the audit session over TR-001..TR-017 is now executable
  by a fresh session on Selina's word.
- **v0.12 (2026-08-30)** — **The lane is on GitHub**: pushed to
  Selina's own PRIVATE repo github.com/selinaserephina-star/Scar_merkabit
  (created by her; 42 files incl. the sent zips and their recorded
  hashes; staging dirs excluded). Private = a version-controlled home,
  not a send — the two-party rule governs any future flip to public
  (Ilya's word required). Local folder remains the working copy;
  re-push after edits.
- **v0.11 (2026-08-30)** — **THE SEND MADE.** Complete package delivered
  to Ilya on Selina's word. The joint world is now fully two-party:
  everything sealed here is in both authors' hands.
- **v0.10 (2026-08-30)** — **Sends ledger CORRECTED on Selina's word**
  (only the two bridge documents were ever sent) and the **COMPLETE
  package built**: `package/Scar_merkabit_COMPLETE_2026-08-30.zip`
  (36 files, 1,305,365 bytes staged; zip 464,611 bytes, **sha256
  d74cdb6400ddc28ff431fe0025e64f0a074d589fcc3aa70496d4d0430f0d1539**),
  entry point = the NEW `to_Ilya/Joint_World_Compendium_2026-08-30`
  (.md/.docx): the full theorem compendium written for a reader who has
  seen only the bridge — audit summary, resurrection, depth theorems,
  field theorems, the auditor's six-refutation ledger, open problems,
  invitations. Manifest with all hashes + the 11 verification commands
  inside; zip hash in `package/COVER_COMPLETE_SHA256.txt`. Supersedes
  the v0.2 zip. Handing it over is the send — Selina's to make.
- **v0.9 (2026-08-30)** — **Stone F(d) done: the machine sings.** The
  56-State Machine artifact gained the **Waves view**: pick a clock orbit
  and harmonic, the standing wave is phase-painted onto the mirrored board
  (hue = phase; ▶ tick animates the global phase, reduced-motion
  respected); the axis frame O3 labelled; spec panels carry the day's
  depth ladder (Ψ-depth 2 / W-depth 4) and the field facts; the census
  strip is now captioned as the trace formula it is. Functionally
  verified live (orbit switching, harmonic re-capping, eigenvalue
  read-outs incl. ζ₁₈⁹ on the axis mode, gates unaffected). Same URL,
  version 'waves-view'. **Stone F complete: (a) spectrum, (b) DQ-1 +
  erratum, (c) quantum lift, (d) the panel.**
- **v0.8 (2026-08-30)** — **Stone F(c) done** (SM-014): the quantum lift.
  Parallel-magic unitary certificate PROVED-and-verified (max + parity
  superselection); 56 frame-quantum group order 2·8²⁸·28!, W-depth
  exactly 4; the mixed clock+splitter regime identified as the true open
  frontier. Remaining in Stone F: (d) the spectral artifact panel.
- **v0.7 (2026-08-30)** — **Stone F(b) done** (SM-013): DQ-1 closed
  ([28,28]); SM-012's chirality-odd-quarks claim REFUTED and errata'd in
  place (backport rule honoured same-day); second PSL(2,7) class found
  (Fano-doubled action). Two auditor predictions died in one stone —
  both recorded.
- **v0.6 (2026-08-30)** — **Stone F(a) done** (SM-012, "Stone F — go"):
  the field lift; CSP = standing-wave trace formula; the clock's axis
  frame; DQ-4 closed; pr frequency-mixing; chirality-odd quark sectors.
  Next: F(b) DQ-1 explicit action; F(c) the honest quantum lift; F(d)
  the artifact's spectral panel.
- **v0.5 (2026-08-30)** — **Methods note drafted** (SM-011) on Selina's
  word: Stones 1a+1b assembled into the second joint paper; awaiting
  Ilya's review pass alongside the bridge paper. KCP updated (methods
  note, stone docs, campaign scripts wired in).
- **v0.4 (2026-08-30)** — **Stone 1b done** (SM-010): the hyperoctahedral
  composition calculus built and validated; two law-guesses refuted on
  exact data; the (S₂ₙ,Bₙ) support law identified as the real open problem
  (our n≤7 tables = its data); and the SECOND depth-2 theorem — frame
  grammar, 3718/3718 verified witnesses. The 56-machine is depth-2 in both
  grammars. New open: the hyperoctahedral support law.
- **v0.3 (2026-08-30)** — **Stone 1 run on Selina's "lets run it"**: SM-009
  sealed (see row). Three new theorems on first contact: 27-Young depth 3,
  56-Young depth 5, 56-wreath depth 2; the S₃ buys one gate, the mirror
  buys three; certificate method transfers unchanged in the Young/wreath
  regime; hyperoctahedral frontier mapped. New open added: "is wreath-depth
  2 generic for crystal clocks?"
- **v0.2 (2026-08-30)** — **Package for Ilya prepared** on Selina's word:
  `package/Scar_merkabit_2026-08-30.zip` (20 files, 267,442 bytes staged;
  zip 144,023 bytes, **sha256
  c4194b93ac8bc58afe4b046da5e582058ab8e259937bd52c37eea0f8cfaf727b**),
  containing the full lane + `MANIFEST_SHA256.txt` (per-file hashes + the
  94-check verification commands); zip hash kept outside the archive in
  `package/COVER_SHA256.txt`. Handing the zip to Ilya is a send — Selina's
  to make; recorded here when made.

- **v0.1 (2026-08-30)** — Registry founded; units SM-001..SM-008 consolidated
  from Corpus_triage changelog v0.20–v0.25 (where this lane's history lived
  before it became self-governing); KCP `knowledge.yaml` created (joint
  authority: external sharing requires BOTH parties). Prior history remains
  readable in `../Corpus_triage/TRIAGE_REGISTRY.md`; from v0.1 on, this lane
  records itself here.
