# SCAR–MERKABIT JOINT REGISTRY

**The single source of truth for the joint world. Founded 2026-08-30.**
Parties: **Selina Stenberg** (Merkabit / E₆-crystal lane) and **Ilya Balashov**
(Scar-Cat / PSL(2,7) lane), with Claude. This lane is where the two programs
meet; it governs itself (see `knowledge.yaml`, the lane KCP) and inherits the
shared house rules both sides now run on:

> **Compute, never assert. Refutations at equal prominence — including the
> auditor's own. Mathematics split from identification (Rule 3). Every
> decimal match is a fit until proven derived. Every emergence claim needs a
> control. Backport rule (T-SC-P1): a downstream falsification must reach
> the upstream registry within one revision.**

Grades: [P] proved here/classical (cited) · [C] computed exactly by a named
script · [obs] observation not located in the literature · [I] role/
interpretation · [OPEN]. Joint-lane rule: **a unit is JOINT once both
parties have seen it; sends and publication require both parties' word.**

## Sealed units

| id | unit | result | grade | artifacts |
|---|---|---|---|---|
| SM-001 | **Scar-Cat registry audit** (T-SC) | PSL(2,7) rebuilt twice from scratch; character table DERIVED (Burnside–Dixon) and verified exactly in ℚ(√−7); **35+ "GAP" rows of Ilya's registry independently confirmed**, 9 classical; his note-7 self-audit credited in full. 48 checks. | [C] | `TSC_SCARCAT.md`, `verify_tsc_scarcat.py` |
| SM-002 | **Corrections R-SC-1..5** | T4-Higgs channel count 4 not 5 (⟨χ₃²,χ₁⟩=0); MOLIEN-REC fails for χ₆ (+ char.poly typo); 140's cube contains χ̄₃; 125's "7×ℤ₇⋊ℤ₃" → 8; **λ=1/8 ⇒ m_H=123.11 GeV ≈13σ hidden failure**. Each with a GAP one-liner in the report. | [C] | same + `to_Ilya/Scar_Cat_Verification_Report` |
| SM-003 | **The bitangent bridge** (T-BR) | Field level: ℚ(ζ₂₁) = compositum of the two character fields (√−3, √−7; √21 forced), linearly disjoint. E₆ level: no-go (7∤51840; no transitive 27-action). E₇ level: in Sp₆(2)=W(E₇)/± on the Klein quartic's 28 bitangents, **W(E₆) = stabilizer of one bitangent, PSL(2,7) transitive on all 28, intersection = S₃ = N(⟨z₃⟩)** — Ilya's universal stabilizer = the T4 strata S₃ = the E₆ machine's type group; 3A → bitangents exactly 2:1 (56=2×28); PSL fixes one even theta char (stab 8!; even orbits **[1,7,7,21]** [obs]); π₂₈ = χ₁⊕2χ₆⊕χ₇⊕χ₈. Lie level: 27\| = 3χ₁⊕3χ₈ (trinification/Klein χ₃) or 6χ₁⊕3χ₇ (G₂); "=2χ₈" refuted. **Closes Ilya's open "Bridge" conjecture row.** 20 checks. | [C]/[P] | `TBR_BRIDGE.md`, `verify_tbr_bridge.py`, `to_Ilya/The_Bridge_Report` |
| SM-004 | **The chiral Fano pair** | The E₆ architecture's 7-channel syndrome is NOT Fano-organized (motion group = S₃: pr rotates legs, ξ flips, Ψ inert; incidence = affine E₆ tree) but is **one bit away**: of 30 Fanos exactly 2 invariant — a chiral pair sharing the 3 centre-lines, swapped by inner/outer duality [obs]. 14 checks. | [C] | `verify_fano_syndrome.py` |
| SM-005 | **THE RESURRECTION THEOREM** (DQ-6) | E₆-branching of E₇'s 56 = **27 ⊕ 27̄ ⊕ 1 ⊕ 1**; the odd gate pr (1²·2²⁷) fixes exactly the two singlets and cross-pairs the sheets; the antipode ι is a second, inequivalent duality (3/27 pairings shared); Ψ crosses the wall. **v1's dual-spinor picture, refuted at E₆ (Thm 3.3), is TRUE at E₇.** Corollary (DQ-2, partial): **pr and ι are bilingual** (μ_branch = μ_frame = 0); the clock is the sole magic source (μ_branch(Ψ)=21/56, μ_frame(Ψ)=27/56) — *structure is free; only time is expensive.* 12 checks. Includes one refuted auditor guess (Ψ⁹-pairing ≠ ι-pairing, 4/28). | [C] | `verify_dq6_resurrection.py`, `scar56_data.json` |
| SM-006 | **The 56-State Machine** (instrument) | Interactive simulator of the joint architecture: mirrored two-sheet board hinged on the pr-axis vacua; frame view (28 ι-frames × chirality); both magic meters exact (μ_frame via true 28×28 assignment, validated against scipy); parity lamp; clock census. All tables emitted by the DQ-6 verifier. Published (private) at claude.ai/code/artifact/a7d069f2-be97-45fa-b5af-6524e858eb82. | [C] instrument | `artifact_56/machine56.html` |
| SM-007 | **The 56-machine design brief** | The joint architecture: 28 frames × chirality bit; three gate families (clock / odd mirror / antipode); two-axis resource theory (μ_typed, μ_SC); design questions DQ-1..5 (DQ-6 answered → SM-005; DQ-2 partial). | [I]+[C] anchors | `56_MACHINE_BRIEF.md` |
| SM-008 | **Joint paper draft v0.1** | *The Bitangent Bridge* — Stenberg · Balashov (co-authorship confirmed by Selina 2026-08-30): §§1–9 incl. §7½ resurrection + bilingual gates; §8 separates classical skeleton from [obs] items. Awaiting Ilya's review pass + joint bibliography. | draft | `joint_paper/Bitangent_Bridge_DRAFT.md/.docx` |

## Open questions (the joint program)

- **DQ-1**: PSL(2,7)-lift orbits on the 56 weights (one 56-orbit or 28+28?).
- **DQ-2** (remainder): magic growth curves; the (μ_typed, μ_SC) trade-off surface.
- **DQ-3**: the 8-channel affine-E₇ syndrome vs the P¹(𝔽₇) action.
- **DQ-4**: ⟨ι, Ψ⁹⟩; why 4/28 shared pairs; ιΨι =? Ψ⁻¹ on the 56.
- **DQ-5**: frame-fixing as a literal 56→27 descent operation.
- Inherited crystal opens: exact Cayley diameter (conj. 91–95), shortest pr/Ψ⁴ relation.

## Sends & publication status

- 2026-08-30, per Selina's word: **most pieces sent to Ilya individually**
  (reports, brief, draft; itemization to be confirmed by her — the registry
  records sends only on a party's word).
- **Publication intent recorded** (Selina, 2026-08-30: "publishing this is
  the way"): the paper to arXiv/OSF after Ilya's review pass; the lane to a
  public repo on the joint go. Until both words are in: DRAFT /
  sealed-not-sent.
- The 56-Machine artifact is private; sharing its link is a send.

## Changelog

- **v0.1 (2026-08-30)** — Registry founded; units SM-001..SM-008 consolidated
  from Corpus_triage changelog v0.20–v0.25 (where this lane's history lived
  before it became self-governing); KCP `knowledge.yaml` created (joint
  authority: external sharing requires BOTH parties). Prior history remains
  readable in `../Corpus_triage/TRIAGE_REGISTRY.md`; from v0.1 on, this lane
  records itself here.
